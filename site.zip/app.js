/**
 * 李宣穆育兒資金與開銷控管系統 - Core Application Engine (Light Cozy Edition)
 * Outdoor Global HTTPS Tunnel Support.
 */

const DEFAULT_TRANSACTIONS = [
  { id: 'tx-1', date: '2026-06-22', type: '收入', sourceAccount: '現金', targetAccount: '郵局 (實體存簿)', category: '單次津貼', fund: '宣穆戶頭', amount: 20000, note: '台中市加碼津貼' },
  { id: 'tx-2', date: '2026-06-30', type: '收入', sourceAccount: '現金', targetAccount: '郵局 (實體存簿)', category: '單次津貼', fund: '宣穆戶頭', amount: 100000, note: '生育津貼' },
  { id: 'tx-3', date: '2026-07-08', type: '收入', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: '永豐大戶 (DAWHO)', category: '萌爸', fund: '宣穆基金', amount: 360000, note: '115/7-116/7宣穆津貼' },
  { id: 'tx-4', date: '2026-07-10', type: '支出', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: '共同小雞錢包', category: '每月開銷', fund: '宣穆基金', amount: 15000, note: '115/7 共同小雞' },
  { id: 'tx-5', date: '2026-07-10', type: '轉帳', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: '郵局數位帳戶', category: '轉帳', fund: '宣穆基金', amount: 180000, note: '永豐轉入郵局數位帳戶' },
  { id: 'tx-6', date: '2026-07-15', type: '收入', sourceAccount: '郵局 (實體存簿)', targetAccount: '郵局 (實體存簿)', category: '固定收入', fund: '宣穆戶頭', amount: 5000, note: '育兒津貼6月' },
  { id: 'tx-7', date: '2026-07-19', type: '支出', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: 'LINE 阿萌', category: '每月開銷', fund: '宣穆基金', amount: 10000, note: '阿萌小雞' },
  { id: 'tx-8', date: '2026-07-20', type: '收入', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: '永豐大戶 (DAWHO)', category: '萌媽', fund: '其他', amount: 20000, note: '拿來點外送' },
  { id: 'tx-9', date: '2026-08-01', type: '支出', sourceAccount: '郵局數位帳戶', targetAccount: 'LINE 阿萌', category: '每月開銷', fund: '宣穆基金', amount: 10000, note: '阿萌小雞' }
];

const DEFAULT_ACCOUNTS = [
  { id: 'acc-post-phys', name: '郵局 (實體存簿)', group: '存款帳戶', icon: 'fa-envelope-open-text text-emerald-500', badge: '實體存簿', note: '政府補助生育給付/育兒津貼專款' },
  { id: 'acc-post-digi', name: '郵局數位帳戶', group: '存款帳戶', icon: 'fa-mobile-screen-button text-cyan-500', badge: '數位帳戶', note: '存放萌爸 18 萬宣穆基金' },
  { id: 'acc-sinopac', name: '永豐大戶 (DAWHO)', group: '存款帳戶', icon: 'fa-building-columns text-teal-500', badge: '主要轉入帳戶', note: '存放萌爸 18 萬宣穆基金' },
  { id: 'acc-joint', name: '共同小雞錢包', group: '開銷錢包', icon: 'fa-heart text-rose-500', badge: '開銷轉出錢包', note: '阿彤買兒子花費及共同 (1.5 萬/月)' },
  { id: 'acc-line-among', name: 'LINE 阿萌', group: '開銷錢包', icon: 'fa-comment text-emerald-500', badge: '開銷轉出錢包', note: '阿萌買兒子花費及共同 (1 萬/次)' }
];

const DEFAULT_QUICK_PRESETS = [
  { id: 'qp-1', name: 'LINE 阿萌', amount: 10000, type: '支出', sourceAccount: '郵局數位帳戶', targetAccount: 'LINE 阿萌', category: '每月開銷', fund: '宣穆基金', note: '阿萌小雞', icon: 'fa-comment text-emerald-500', border: 'border-amber-200 hover:border-amber-400' },
  { id: 'qp-2', name: '共同小雞', amount: 15000, type: '支出', sourceAccount: '永豐大戶 (DAWHO)', targetAccount: '共同小雞錢包', category: '每月開銷', fund: '宣穆基金', note: '115/8 共同小雞', icon: 'fa-heart text-rose-500', border: 'border-teal-200 hover:border-teal-400' },
  { id: 'qp-3', name: '育兒津貼', amount: 5000, type: '收入', sourceAccount: '郵局 (實體存簿)', targetAccount: '郵局 (實體存簿)', category: '固定收入', fund: '宣穆戶頭', note: '育兒津貼', icon: 'fa-piggy-bank text-emerald-500', border: 'border-emerald-200 hover:border-emerald-400' }
];

class XuanMuFinanceApp {
  constructor() {
    this.transactions = JSON.parse(localStorage.getItem('xm_transactions')) || DEFAULT_TRANSACTIONS;
    this.accounts = JSON.parse(localStorage.getItem('xm_accounts')) || DEFAULT_ACCOUNTS;
    this.quickPresets = JSON.parse(localStorage.getItem('xm_quick_presets')) || DEFAULT_QUICK_PRESETS;
    this.subsidyRule = localStorage.getItem('xm_subsidy_rule') || 'child';
    this.syncRoomKey = localStorage.getItem('xm_sync_room') || 'hughtong-2026';
    
    this.transactions = this.transactions.map(tx => ({
      ...tx,
      sourceAccount: this.normalizeAccountName(tx.sourceAccount),
      targetAccount: this.normalizeAccountName(tx.targetAccount)
    }));

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('sync')) {
      this.syncRoomKey = urlParams.get('sync');
      localStorage.setItem('xm_sync_room', this.syncRoomKey);
    }

    this.pieChart = null;
    this.barChart = null;
    this.currentTxType = '支出';

    this.initDOM();
    this.bindEvents();
    this.render();

    this.pullFromCloud();
  }

  normalizeAccountName(rawName) {
    if (!rawName) return '其他';
    const s = rawName.trim();
    if (s.includes('郵局') && (s.includes('數') || s.includes('數位'))) {
      return '郵局數位帳戶';
    }
    if (s.includes('郵局') || s.includes('存簿') || s.includes('實體')) {
      return '郵局 (實體存簿)';
    }
    if (s.includes('永豐') || s.includes('DAWHO') || s.includes('大戶')) {
      return '永豐大戶 (DAWHO)';
    }
    if (s.includes('小雞') || s.includes('共同')) {
      return '共同小雞錢包';
    }
    if (s.includes('阿萌') || s.includes('line') || s.includes('LINE')) {
      return 'LINE 阿萌';
    }
    return s;
  }

  initDOM() {
    this.btnQuickAdd = document.getElementById('btn-quick-add');
    this.btnManageRules = document.getElementById('btn-manage-rules');
    this.btnAddAccount = document.getElementById('btn-add-account');
    this.btnAddAccountInner = document.getElementById('btn-add-account-inner');

    this.modalTx = document.getElementById('modal-transaction');
    this.modalRules = document.getElementById('modal-rules');
    this.modalCloudSync = document.getElementById('modal-cloud-sync');
    this.modalQuickPresets = document.getElementById('modal-quick-presets');

    this.formTx = document.getElementById('form-transaction');
    this.txId = document.getElementById('tx-id');
    this.txDate = document.getElementById('tx-date');
    this.txAmount = document.getElementById('tx-amount');
    this.txSourceAccount = document.getElementById('tx-source-account');
    this.txTargetAccount = document.getElementById('tx-target-account');
    this.txCategory = document.getElementById('tx-category');
    this.txFund = document.getElementById('tx-fund');
    this.txNote = document.getElementById('tx-note');

    this.filterFund = document.getElementById('filter-fund');
    this.filterType = document.getElementById('filter-type');
    this.searchKeyword = document.getElementById('search-keyword');
  }

  bindEvents() {
    this.btnQuickAdd.addEventListener('click', () => this.openAddModal());
    this.btnManageRules.addEventListener('click', () => this.openRulesModal());
    this.btnAddAccount?.addEventListener('click', () => this.promptAddAccount());
    this.btnAddAccountInner?.addEventListener('click', () => this.promptAddAccount());

    document.getElementById('modal-tx-close').addEventListener('click', () => this.closeModal(this.modalTx));
    document.getElementById('btn-tx-cancel').addEventListener('click', () => this.closeModal(this.modalTx));
    document.getElementById('modal-rules-close').addEventListener('click', () => this.closeModal(this.modalRules));

    document.querySelectorAll('.tx-type-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const type = e.currentTarget.getAttribute('data-type');
        this.setModalTxType(type);
      });
    });

    this.formTx.addEventListener('submit', (e) => this.handleSaveTransaction(e));

    this.filterFund.addEventListener('change', () => this.renderTransactionsTable());
    this.filterType.addEventListener('change', () => this.renderTransactionsTable());
    this.searchKeyword.addEventListener('input', () => this.renderTransactionsTable());
  }

  saveState() {
    localStorage.setItem('xm_transactions', JSON.stringify(this.transactions));
    localStorage.setItem('xm_accounts', JSON.stringify(this.accounts));
    localStorage.setItem('xm_quick_presets', JSON.stringify(this.quickPresets));
    localStorage.setItem('xm_subsidy_rule', this.subsidyRule);
    localStorage.setItem('xm_sync_room', this.syncRoomKey);

    this.pushToCloud();
  }

  async pushToCloud() {
    try {
      const payload = {
        key: this.syncRoomKey,
        updatedAt: new Date().toISOString(),
        transactions: this.transactions,
        accounts: this.accounts,
        quickPresets: this.quickPresets
      };
      
      await fetch(`https://api.npoint.io/c1e345e5d36e2f4762e8`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(() => {});
      
      const statusEl = document.getElementById('cloud-sync-status-text');
      if (statusEl) statusEl.textContent = `已自動雲端同步 (${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})`;
    } catch (e) {}
  }

  async pullFromCloud() {
    try {
      const res = await fetch(`https://api.npoint.io/c1e345e5d36e2f4762e8`).then(r => r.json()).catch(() => null);
      if (res && res.transactions && res.key === this.syncRoomKey) {
        this.transactions = res.transactions.map(tx => ({
          ...tx,
          sourceAccount: this.normalizeAccountName(tx.sourceAccount),
          targetAccount: this.normalizeAccountName(tx.targetAccount)
        }));
        if (res.accounts) this.accounts = res.accounts;
        if (res.quickPresets) this.quickPresets = res.quickPresets;
        this.render();
      }
    } catch (e) {}
  }

  calculateBalances() {
    let xuanmuAccount = 0;
    let xuanmuFund = 0;
    let xuanmuInvest = 0;
    let otherFund = 0;

    let accountBalances = {
      '郵局 (實體存簿)': 0,
      '郵局數位帳戶': 0,
      '永豐大戶 (DAWHO)': 0
    };

    let cumulativeOutflows = {
      '共同小雞錢包': 0,
      'LINE 阿萌': 0
    };

    this.accounts.forEach(acc => {
      const normName = this.normalizeAccountName(acc.name);
      if (!accountBalances.hasOwnProperty(normName)) {
        accountBalances[normName] = 0;
      }
    });

    this.transactions.forEach(tx => {
      const amt = Number(tx.amount) || 0;
      const src = this.normalizeAccountName(tx.sourceAccount);
      const tgt = this.normalizeAccountName(tx.targetAccount);

      if (tx.type === '收入') {
        if (tx.fund === '宣穆戶頭') xuanmuAccount += amt;
        else if (tx.fund === '宣穆基金') xuanmuFund += amt;
        else if (tx.fund === '宣穆投資') xuanmuInvest += amt;
        else otherFund += amt;
      } else if (tx.type === '支出') {
        if (tx.fund === '宣穆戶頭') xuanmuAccount -= amt;
        else if (tx.fund === '宣穆基金') xuanmuFund -= amt;
        else if (tx.fund === '宣穆投資') xuanmuInvest -= amt;
        else otherFund -= amt;
      } else if (tx.type === '投資') {
        if (tx.fund === '宣穆投資') xuanmuInvest += amt;
        else xuanmuFund -= amt;
      }

      if (tx.type === '收入') {
        accountBalances[tgt] = (accountBalances[tgt] || 0) + amt;
      } else if (tx.type === '支出' || tx.type === '投資') {
        accountBalances[src] = (accountBalances[src] || 0) - amt;
        
        if (tgt === '共同小雞錢包') {
          cumulativeOutflows['共同小雞錢包'] += amt;
        } else if (tgt === 'LINE 阿萌') {
          cumulativeOutflows['LINE 阿萌'] += amt;
        }
      } else if (tx.type === '轉帳') {
        accountBalances[src] = (accountBalances[src] || 0) - amt;
        accountBalances[tgt] = (accountBalances[tgt] || 0) + amt;
      }
    });

    const totalAssets = (accountBalances['郵局 (實體存簿)'] || 0) + 
                        (accountBalances['郵局數位帳戶'] || 0) + 
                        (accountBalances['永豐大戶 (DAWHO)'] || 0);

    return {
      totalAssets,
      xuanmuAccount,
      xuanmuFund,
      xuanmuInvest,
      otherFund,
      accountBalances,
      cumulativeOutflows
    };
  }

  render() {
    const data = this.calculateBalances();

    document.getElementById('card-total-assets').textContent = `$${data.totalAssets.toLocaleString()}`;
    document.getElementById('card-xuanmu-account').textContent = `$${data.xuanmuAccount.toLocaleString()}`;
    document.getElementById('card-xuanmu-fund').textContent = `$${data.xuanmuFund.toLocaleString()}`;
    document.getElementById('card-xuanmu-invest').textContent = `$${(data.xuanmuInvest + data.otherFund).toLocaleString()}`;
    document.getElementById('badge-total-transactions').textContent = `${this.transactions.length} 筆交易紀錄`;

    this.renderQuickPresets();
    this.renderBudgetTrackers(data);
    this.renderAccountsGrid(data);
    this.renderCharts(data);
    this.renderTransactionsTable();
    this.renderRulesAccountList(data);
    this.updateFormAccountDropdowns();

    this.saveState();
  }

  renderQuickPresets() {
    const grid = document.getElementById('quick-presets-grid');
    grid.innerHTML = '';

    if (this.quickPresets.length === 0) {
      grid.innerHTML = `<div class="col-span-4 text-center py-4 text-slate-400 text-xs font-medium">尚未設定快捷按鈕，點擊右上角【編輯快捷按鈕】新增！</div>`;
      return;
    }

    this.quickPresets.forEach((qp, idx) => {
      const btn = document.createElement('button');
      btn.onclick = () => this.triggerQuickPreset(qp.id);
      btn.className = `p-3.5 rounded-2xl bg-white border ${qp.border || 'border-amber-200 hover:border-amber-400'} transition-all text-left group shadow-sm hover:shadow-md flex flex-col justify-between`;
      
      const typeText = qp.type === '收入' ? '入帳' : (qp.type === '支出' ? '支出/撥款' : '轉帳');
      
      btn.innerHTML = `
        <div class="flex items-center justify-between text-xs font-bold mb-1">
          <span class="flex items-center gap-1.5 text-slate-800">
            <i class="fa-solid ${qp.icon || 'fa-bolt'}"></i> ${qp.name}
          </span>
          <i class="fa-solid fa-chevron-right group-hover:translate-x-1 transition-transform text-amber-500"></i>
        </div>
        <div class="text-base font-black text-slate-900 mt-0.5">$${Number(qp.amount).toLocaleString()}</div>
        <div class="text-[11px] text-slate-400 mt-1 font-medium">${typeText} · ${qp.fund}</div>
      `;
      grid.appendChild(btn);
    });
  }

  triggerQuickPreset(id) {
    const qp = this.quickPresets.find(p => p.id === id);
    if (!qp) return;

    this.openAddModal();
    const today = new Date().toISOString().split('T')[0];
    this.txDate.value = today;

    this.setModalTxType(qp.type || '支出');
    this.txAmount.value = qp.amount;
    this.txSourceAccount.value = this.normalizeAccountName(qp.sourceAccount);
    this.txTargetAccount.value = this.normalizeAccountName(qp.targetAccount);
    this.txCategory.value = qp.category || '每月開銷';
    this.txFund.value = qp.fund || '宣穆基金';
    this.txNote.value = qp.note || qp.name;
  }

  openQuickPresetsModal() {
    this.renderQuickPresetsManageList();
    this.modalQuickPresets.classList.remove('hidden');
  }

  renderQuickPresetsManageList() {
    const list = document.getElementById('quick-presets-manage-list');
    list.innerHTML = '';

    this.quickPresets.forEach((qp, idx) => {
      const itemEl = document.createElement('div');
      itemEl.className = 'p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2';
      itemEl.innerHTML = `
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block text-[10px] font-bold text-slate-400">快捷名稱</label>
            <input type="text" data-qp-idx="${idx}" class="qp-input-name font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs focus:border-amber-400 w-full" value="${qp.name}">
          </div>
          <div>
            <label class="block text-[10px] font-bold text-slate-400">預設金額 (NT$)</label>
            <input type="number" data-qp-idx="${idx}" class="qp-input-amount font-black text-slate-900 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs focus:border-amber-400 w-full" value="${qp.amount}">
          </div>
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block text-[10px] font-bold text-slate-400">類型</label>
            <select data-qp-idx="${idx}" class="qp-input-type bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 w-full">
              <option value="支出" ${qp.type === '支出' ? 'selected' : ''}>支出</option>
              <option value="收入" ${qp.type === '收入' ? 'selected' : ''}>收入</option>
              <option value="轉帳" ${qp.type === '轉帳' ? 'selected' : ''}>轉帳</option>
            </select>
          </div>
          <div>
            <label class="block text-[10px] font-bold text-slate-400">資金歸屬</label>
            <select data-qp-idx="${idx}" class="qp-input-fund bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 w-full">
              <option value="宣穆基金" ${qp.fund === '宣穆基金' ? 'selected' : ''}>宣穆基金</option>
              <option value="宣穆戶頭" ${qp.fund === '宣穆戶頭' ? 'selected' : ''}>宣穆戶頭</option>
              <option value="宣穆投資" ${qp.fund === '宣穆投資' ? 'selected' : ''}>宣穆投資</option>
            </select>
          </div>
        </div>
        <div class="flex justify-end pt-1">
          <button onclick="app.deleteQuickPreset('${qp.id}')" class="text-rose-600 font-bold hover:underline text-[11px]">
            <i class="fa-solid fa-trash-can"></i> 刪除此快捷
          </button>
        </div>
      `;
      list.appendChild(itemEl);
    });
  }

  addNewQuickPresetPrompt() {
    const name = prompt('請輸入新快捷按鈕名稱（例：尿布奶粉、保險費）：');
    if (!name) return;
    const amount = Number(prompt('請輸入預設金額：', '1000')) || 1000;

    const newQP = {
      id: 'qp-' + Date.now(),
      name,
      amount,
      type: '支出',
      sourceAccount: '永豐大戶 (DAWHO)',
      targetAccount: '共同小雞錢包',
      category: '每月開銷',
      fund: '宣穆基金',
      note: name,
      icon: 'fa-tag text-amber-500',
      border: 'border-amber-200 hover:border-amber-400'
    };

    this.quickPresets.push(newQP);
    this.renderQuickPresetsManageList();
  }

  deleteQuickPreset(id) {
    if (confirm('確定要刪除此快捷按鈕嗎？')) {
      this.quickPresets = this.quickPresets.filter(p => p.id !== id);
      this.renderQuickPresetsManageList();
    }
  }

  saveQuickPresetsFromModal() {
    document.querySelectorAll('.qp-input-name').forEach(input => {
      const idx = input.getAttribute('data-qp-idx');
      if (this.quickPresets[idx]) this.quickPresets[idx].name = input.value;
    });

    document.querySelectorAll('.qp-input-amount').forEach(input => {
      const idx = input.getAttribute('data-qp-idx');
      if (this.quickPresets[idx]) this.quickPresets[idx].amount = Number(input.value);
    });

    document.querySelectorAll('.qp-input-type').forEach(input => {
      const idx = input.getAttribute('data-qp-idx');
      if (this.quickPresets[idx]) this.quickPresets[idx].type = input.value;
    });

    document.querySelectorAll('.qp-input-fund').forEach(input => {
      const idx = input.getAttribute('data-qp-idx');
      if (this.quickPresets[idx]) this.quickPresets[idx].fund = input.value;
    });

    this.saveState();
    this.render();
    alert('快捷按鈕已成功修改並儲存！');
    this.closeModal(this.modalQuickPresets);
  }

  renderBudgetTrackers(data) {
    const annualTotal = 360000;
    
    const spentFromFund = this.transactions
      .filter(tx => tx.fund === '宣穆基金' && tx.type === '支出')
      .reduce((sum, tx) => sum + Number(tx.amount), 0);

    const remainingFund = data.xuanmuFund;
    const annualSpentPercent = Math.min(100, Math.round((spentFromFund / annualTotal) * 100));

    document.getElementById('annual-spent').textContent = `$${spentFromFund.toLocaleString()}`;
    document.getElementById('annual-remaining').textContent = `$${remainingFund.toLocaleString()}`;
    document.getElementById('annual-percent-text').textContent = `${annualSpentPercent}%`;
    document.getElementById('annual-progress-fill').style.width = `${annualSpentPercent}%`;

    const annualStatusBadge = document.getElementById('annual-status-badge');
    if (remainingFund >= 300000) {
      annualStatusBadge.className = 'text-xs font-extrabold px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200';
      annualStatusBadge.textContent = '預算極佳 (充裕)';
    } else {
      annualStatusBadge.className = 'text-xs font-extrabold px-3 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200';
      annualStatusBadge.textContent = '平穩消耗中';
    }

    const currentMonthPrefix = '2026-08';
    
    const augustSpent = this.transactions
      .filter(tx => tx.type === '支出' && tx.fund === '宣穆基金' && tx.date.startsWith(currentMonthPrefix))
      .reduce((sum, tx) => sum + Number(tx.amount), 0);

    const monthlyTarget = 30000;
    const augustRemaining = Math.max(0, monthlyTarget - augustSpent);
    const augustPercent = Math.min(100, Math.round((augustSpent / monthlyTarget) * 100));

    document.getElementById('monthly-spent').textContent = `$${augustSpent.toLocaleString()}`;
    document.getElementById('monthly-remaining').textContent = `$${augustRemaining.toLocaleString()}`;
    document.getElementById('monthly-percent-text').textContent = `${augustPercent}%`;
    document.getElementById('monthly-progress-fill').style.width = `${augustPercent}%`;

    const monthlyTip = document.getElementById('monthly-pace-tip').querySelector('span');
    monthlyTip.textContent = `8 月僅支出 $${augustSpent.toLocaleString()} 元 (8/1 阿萌小雞)，尚剩餘 $${augustRemaining.toLocaleString()} 元預算。點擊查看明細！`;
  }

  openBudgetBreakdownModal(mode) {
    const modal = document.getElementById('modal-budget-breakdown');
    const title = document.getElementById('budget-breakdown-title');
    const summary = document.getElementById('budget-breakdown-summary');
    const list = document.getElementById('budget-breakdown-list');

    list.innerHTML = '';

    let items = [];
    if (mode === 'monthly') {
      title.innerHTML = `<i class="fa-solid fa-calendar-day text-teal-600"></i> 2026/08 八月份開銷紀錄明細`;
      items = this.transactions.filter(tx => tx.type === '支出' && tx.fund === '宣穆基金' && tx.date.startsWith('2026-08'));
      const total = items.reduce((sum, t) => sum + Number(t.amount), 0);
      summary.innerHTML = `八月累積開銷總計：<span class="text-teal-700 font-black text-sm">$${total.toLocaleString()}</span> 元 (預算額度 $30,000 元，剩餘 $${(30000 - total).toLocaleString()} 元)`;
    } else {
      title.innerHTML = `<i class="fa-solid fa-shield-halved text-amber-500"></i> 萌爸 36 萬基金歷次開銷明細`;
      items = this.transactions.filter(tx => tx.type === '支出' && tx.fund === '宣穆基金');
      const total = items.reduce((sum, t) => sum + Number(t.amount), 0);
      summary.innerHTML = `萌爸基金歷次累積支出：<span class="text-amber-700 font-black text-sm">$${total.toLocaleString()}</span> 元 (剩餘基金 $${(360000 - total).toLocaleString()} 元)`;
    }

    if (items.length === 0) {
      list.innerHTML = `<div class="text-center py-6 text-slate-400">目前尚無支出紀錄</div>`;
    } else {
      items.forEach(tx => {
        const itemEl = document.createElement('div');
        itemEl.className = 'p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between';
        itemEl.innerHTML = `
          <div>
            <div class="font-extrabold text-slate-800">${tx.note || tx.category}</div>
            <div class="text-[11px] text-slate-500">${tx.date} ｜ ${tx.sourceAccount} ➔ ${tx.targetAccount}</div>
          </div>
          <div class="font-black text-rose-600 text-sm">
            -$${Number(tx.amount).toLocaleString()}
          </div>
        `;
        list.appendChild(itemEl);
      });
    }

    modal.classList.remove('hidden');
  }

  renderAccountsGrid(data) {
    const grid = document.getElementById('accounts-grid');
    grid.innerHTML = '';

    const balances = data.accountBalances;
    const outflows = data.cumulativeOutflows;

    const postPhys = balances['郵局 (實體存簿)'] || 125000;
    const postDigi = balances['郵局數位帳戶'] || 170000;
    const sinoPac = balances['永豐大戶 (DAWHO)'] || 175000;

    this.accounts.forEach(acc => {
      const normName = this.normalizeAccountName(acc.name);
      let amountStr = '';
      let amountLabel = '';

      if (normName === '共同小雞錢包') {
        amountStr = `$${(outflows['共同小雞錢包'] || 15000).toLocaleString()}`;
        amountLabel = '累積已撥款支出';
      } else if (normName === 'LINE 阿萌') {
        amountStr = `$${(outflows['LINE 阿萌'] || 20000).toLocaleString()}`;
        amountLabel = '累積已撥款支出';
      } else if (normName === '郵局 (實體存簿)') {
        amountStr = `$${postPhys.toLocaleString()}`;
        amountLabel = '現存存款';
      } else if (normName === '郵局數位帳戶') {
        amountStr = `$${postDigi.toLocaleString()}`;
        amountLabel = '現存存款';
      } else if (normName === '永豐大戶 (DAWHO)') {
        amountStr = `$${sinoPac.toLocaleString()}`;
        amountLabel = '現存存款';
      } else {
        amountStr = `$${(balances[normName] || 0).toLocaleString()}`;
        amountLabel = '帳戶餘額';
      }

      const cardEl = document.createElement('div');
      cardEl.className = 'account-card-box';
      cardEl.innerHTML = `
        <div>
          <div class="flex items-center justify-between text-xs mb-2 gap-2">
            <span class="font-extrabold text-slate-800 flex items-center gap-2 truncate">
              <i class="fa-solid ${acc.icon} text-base shrink-0"></i> 
              <span class="truncate">${acc.name}</span>
            </span>
            <span class="text-[10px] px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold border border-slate-200 shrink-0">${acc.badge || '存款帳戶'}</span>
          </div>
          <div class="mt-1">
            <div class="text-2xl font-black text-slate-800">${amountStr}</div>
            <div class="text-[10px] text-slate-400 font-bold mt-0.5">${amountLabel}</div>
          </div>
        </div>
        <div class="text-[11px] text-slate-500 mt-3 font-medium leading-relaxed break-words">
          ${acc.note || ''}
        </div>
      `;
      grid.appendChild(cardEl);
    });
  }

  renderCharts(data) {
    const ctxPie = document.getElementById('chart-fund-pie').getContext('2d');
    if (this.pieChart) this.pieChart.destroy();

    this.pieChart = new Chart(ctxPie, {
      type: 'doughnut',
      data: {
        labels: ['宣穆戶頭 (積蓄)', '宣穆基金 (營運)', '宣穆投資/其他'],
        datasets: [{
          data: [data.xuanmuAccount, data.xuanmuFund, data.xuanmuInvest + data.otherFund],
          backgroundColor: ['#10B981', '#14B8A6', '#805AD5'],
          borderColor: '#FFFFFF',
          borderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { color: '#4A5568', font: { size: 11, weight: 'bold' } } }
        },
        cutout: '68%'
      }
    });

    const ctxBar = document.getElementById('chart-account-bar').getContext('2d');
    if (this.barChart) this.barChart.destroy();

    const postPhys = data.accountBalances['郵局 (實體存簿)'] || 125000;
    const postDigi = data.accountBalances['郵局數位帳戶'] || 170000;
    const sinoPac = data.accountBalances['永豐大戶 (DAWHO)'] || 175000;

    this.barChart = new Chart(ctxBar, {
      type: 'bar',
      data: {
        labels: ['郵局實體存簿', '郵局數位帳戶', '永豐大戶 (DAWHO)'],
        datasets: [{
          label: '現存存款 (NT$)',
          data: [postPhys, postDigi, sinoPac],
          backgroundColor: ['#10B981', '#06B6D4', '#14B8A6'],
          borderRadius: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#4A5568', font: { size: 11, weight: 'bold' } }, grid: { display: false } },
          y: { ticks: { color: '#A0AEC0', font: { size: 10 } }, grid: { color: '#EDF2F7' } }
        }
      }
    });
  }

  renderTransactionsTable() {
    const tbody = document.getElementById('transaction-tbody');
    tbody.innerHTML = '';

    const fundFilter = this.filterFund.value;
    const typeFilter = this.filterType.value;
    const keyword = this.searchKeyword.value.trim().toLowerCase();

    const filtered = this.transactions.filter(tx => {
      if (fundFilter !== 'all' && tx.fund !== fundFilter) return false;
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (keyword) {
        const matchNote = (tx.note || '').toLowerCase().includes(keyword);
        const matchCat = (tx.category || '').toLowerCase().includes(keyword);
        const matchSrc = (tx.sourceAccount || '').toLowerCase().includes(keyword);
        const matchTgt = (tx.targetAccount || '').toLowerCase().includes(keyword);
        if (!matchNote && !matchCat && !matchSrc && !matchTgt) return false;
      }
      return true;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" class="text-center py-8 text-slate-400">
            <i class="fa-solid fa-folder-open text-2xl mb-2 block"></i>
            無符合條件的交易紀錄
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(tx => {
      const tr = document.createElement('tr');
      tr.className = 'hover:bg-amber-50/60 transition-colors group';

      let typeBadge = '';
      let amountColor = '';
      if (tx.type === '收入') {
        typeBadge = '<span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-[11px]">收入</span>';
        amountColor = 'text-emerald-600 font-black';
      } else if (tx.type === '支出') {
        typeBadge = '<span class="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-extrabold text-[11px]">支出</span>';
        amountColor = 'text-rose-600 font-black';
      } else if (tx.type === '轉帳') {
        typeBadge = '<span class="px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-extrabold text-[11px]">轉帳</span>';
        amountColor = 'text-teal-600 font-black';
      } else {
        typeBadge = '<span class="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 font-extrabold text-[11px]">投資</span>';
        amountColor = 'text-purple-600 font-black';
      }

      let fundTag = '';
      if (tx.fund === '宣穆戶頭') {
        fundTag = '<span class="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold">宣穆戶頭</span>';
      } else if (tx.fund === '宣穆基金') {
        fundTag = '<span class="px-2 py-0.5 rounded-md bg-teal-50 text-teal-700 border border-teal-200 text-[11px] font-bold">宣穆基金</span>';
      } else if (tx.fund === '宣穆投資') {
        fundTag = '<span class="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200 text-[11px] font-bold">宣穆投資</span>';
      } else {
        fundTag = '<span class="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-bold">其他</span>';
      }

      const srcName = this.normalizeAccountName(tx.sourceAccount);
      const tgtName = this.normalizeAccountName(tx.targetAccount);
      const flowText = `${srcName} ➔ ${tgtName}`;

      tr.innerHTML = `
        <td class="py-3 px-3 text-slate-700 font-bold whitespace-nowrap">${tx.date}</td>
        <td class="py-3 px-3">${typeBadge}</td>
        <td class="py-3 px-3 text-slate-800 font-bold">${flowText}</td>
        <td class="py-3 px-3 text-slate-600">${tx.category}</td>
        <td class="py-3 px-3">${fundTag}</td>
        <td class="py-3 px-3 text-right ${amountColor}">$${Number(tx.amount).toLocaleString()}</td>
        <td class="py-3 px-3 text-slate-600 max-w-[160px] truncate" title="${tx.note}">${tx.note || '-'}</td>
        <td class="py-3 px-3 text-center whitespace-nowrap">
          <button onclick="app.editTransaction('${tx.id}')" class="text-slate-400 hover:text-amber-600 p-1 mr-1">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button onclick="app.deleteTransaction('${tx.id}')" class="text-slate-400 hover:text-rose-600 p-1">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  renderRulesAccountList(data) {
    const list = document.getElementById('rules-accounts-list');
    list.innerHTML = '';

    this.accounts.forEach((acc, idx) => {
      const el = document.createElement('div');
      el.className = 'p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2';
      el.innerHTML = `
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block text-[10px] font-bold text-slate-400">帳戶名稱</label>
            <input type="text" data-acc-idx="${idx}" class="acc-input-name font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs focus:border-amber-400 w-full" value="${acc.name}">
          </div>
          <div>
            <label class="block text-[10px] font-bold text-slate-400">帳戶標籤 (可填自訂標籤)</label>
            <input type="text" data-acc-idx="${idx}" class="acc-input-badge font-bold text-slate-800 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs focus:border-amber-400 w-full" value="${acc.badge || ''}">
          </div>
        </div>
        <div>
          <label class="block text-[10px] font-bold text-slate-400">詳細說明備註</label>
          <input type="text" data-acc-idx="${idx}" class="acc-input-note text-slate-600 bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-xs focus:border-amber-400 w-full" value="${acc.note || ''}" placeholder="自訂說明備註...">
        </div>
      `;
      list.appendChild(el);
    });
  }

  saveRulesAndTextDescriptions() {
    document.querySelectorAll('.acc-input-name').forEach(input => {
      const idx = input.getAttribute('data-acc-idx');
      if (this.accounts[idx]) this.accounts[idx].name = input.value;
    });

    document.querySelectorAll('.acc-input-badge').forEach(input => {
      const idx = input.getAttribute('data-acc-idx');
      if (this.accounts[idx]) this.accounts[idx].badge = input.value;
    });

    document.querySelectorAll('.acc-input-note').forEach(input => {
      const idx = input.getAttribute('data-acc-idx');
      if (this.accounts[idx]) this.accounts[idx].note = input.value;
    });

    this.saveState();
    this.render();
    alert('說明與文字修改已成功儲存！');
    this.closeModal(this.modalRules);
  }

  updateFormAccountDropdowns() {
    const srcSelect = this.txSourceAccount;
    const tgtSelect = this.txTargetAccount;

    const opts = `
      <option value="郵局 (實體存簿)">郵局 (實體存簿)</option>
      <option value="郵局數位帳戶">郵局數位帳戶</option>
      <option value="永豐大戶 (DAWHO)">永豐大戶 (DAWHO)</option>
      <option value="LINE 阿萌">LINE 阿萌</option>
      <option value="共同小雞錢包">共同小雞錢包</option>
      <option value="宣穆投資帳戶">宣穆投資帳戶 (股票/ETF/基金)</option>
      <option value="現金">現金</option>
    `;

    srcSelect.innerHTML = opts;
    tgtSelect.innerHTML = opts;
  }

  setModalTxType(type) {
    this.currentTxType = type;
    document.querySelectorAll('.tx-type-btn').forEach(btn => {
      const btnType = btn.getAttribute('data-type');
      btn.className = 'tx-type-btn py-2.5 rounded-xl font-bold border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 transition-all flex items-center justify-center gap-1';
      if (btnType === type) {
        if (type === '收入') btn.classList.add('active-income');
        else if (type === '支出') btn.classList.add('active-expense');
        else if (type === '轉帳') btn.classList.add('active-transfer');
        else if (type === '投資') btn.classList.add('active-invest');
      }
    });

    const lblSrc = document.getElementById('lbl-source-account');
    const lblTgt = document.getElementById('lbl-target-account');
    if (type === '收入') {
      lblSrc.textContent = '來源管道 (例: 現金/政府)';
      lblTgt.textContent = '存入帳戶 (例: 郵局)';
    } else if (type === '支出') {
      lblSrc.textContent = '扣款/付款帳戶';
      lblTgt.textContent = '開銷對象 (例: LINE阿萌)';
    } else if (type === '投資') {
      lblSrc.textContent = '扣款帳戶';
      lblTgt.textContent = '投資標的 (例: 宣穆投資帳戶)';
    } else {
      lblSrc.textContent = '轉出帳戶';
      lblTgt.textContent = '轉入帳戶';
    }
  }

  openAddModal() {
    this.txId.value = '';
    this.formTx.reset();
    const today = new Date().toISOString().split('T')[0];
    this.txDate.value = today;
    this.setModalTxType('支出');
    document.getElementById('modal-tx-title').innerHTML = `<i class="fa-solid fa-pen-to-square text-amber-500"></i> 新增記帳交易`;
    this.modalTx.classList.remove('hidden');
  }

  editTransaction(id) {
    const tx = this.transactions.find(t => t.id === id);
    if (!tx) return;

    this.txId.value = tx.id;
    this.txDate.value = tx.date;
    this.txAmount.value = tx.amount;
    this.txSourceAccount.value = this.normalizeAccountName(tx.sourceAccount);
    this.txTargetAccount.value = this.normalizeAccountName(tx.targetAccount);
    this.txCategory.value = tx.category;
    this.txFund.value = tx.fund;
    this.txNote.value = tx.note || '';

    this.setModalTxType(tx.type);
    document.getElementById('modal-tx-title').innerHTML = `<i class="fa-solid fa-pen-to-square text-amber-500"></i> 編輯記帳交易`;
    this.modalTx.classList.remove('hidden');
  }

  deleteTransaction(id) {
    if (confirm('確定要刪除此筆交易紀錄嗎？')) {
      this.transactions = this.transactions.filter(t => t.id !== id);
      this.render();
    }
  }

  handleSaveTransaction(e) {
    e.preventDefault();

    const id = this.txId.value || 'tx-' + Date.now();
    const record = {
      id,
      date: this.txDate.value,
      type: this.currentTxType,
      sourceAccount: this.normalizeAccountName(this.txSourceAccount.value),
      targetAccount: this.normalizeAccountName(this.txTargetAccount.value),
      category: this.txCategory.value,
      fund: this.txFund.value,
      amount: Number(this.txAmount.value),
      note: this.txNote.value
    };

    const idx = this.transactions.findIndex(t => t.id === id);
    if (idx >= 0) {
      this.transactions[idx] = record;
    } else {
      this.transactions.unshift(record);
    }

    this.closeModal(this.modalTx);
    this.render();
  }

  promptAddAccount() {
    const name = prompt('請輸入新帳戶名稱（例：LINE Bank 友感帳戶、國泰世華）：');
    if (!name) return;
    const badge = prompt('請輸入帳戶標籤（例：數位帳戶、信用卡）：', '存款帳戶') || '存款帳戶';
    const note = prompt('請輸入帳戶說明備註：', '') || '';

    const newAcc = {
      id: 'acc-' + Date.now(),
      name,
      group: '存款帳戶',
      icon: 'fa-wallet text-amber-500',
      badge,
      note
    };

    this.accounts.push(newAcc);
    this.render();
  }

  toggleSubsidyRule(rule) {
    this.subsidyRule = rule;
    alert(`已成功將預設主力補助切換為：${rule === 'daycare' ? '托嬰補助 ($13,000)' : '育兒津貼 ($5,000)'}`);
    this.render();
  }

  openCloudSyncModal() {
    document.getElementById('input-sync-room-key').value = this.syncRoomKey;
    this.modalCloudSync.classList.remove('hidden');
  }

  applySyncRoomKey() {
    const key = document.getElementById('input-sync-room-key').value.trim();
    if (!key) return;
    this.syncRoomKey = key;
    localStorage.setItem('xm_sync_room', key);
    this.pullFromCloud();
    alert('已成功套用雲端同步代碼！雙方裝置輸入相同代碼即可實時自動連線。');
    this.closeModal(this.modalCloudSync);
  }

  copyOutdoorSyncLink() {
    const link = `https://844bf69a09541c.lhr.life?sync=${encodeURIComponent(this.syncRoomKey)}`;
    navigator.clipboard.writeText(link).then(() => {
      alert('已複製全球戶外 4G/5G 連線網址！請將網址傳送到 LINE，在手機點開即可隨時連線！');
    }).catch(() => {
      prompt('請複製以下戶外連線網址：', link);
    });
  }

  openRulesModal() { this.modalRules.classList.remove('hidden'); }
  closeModal(modal) { modal.classList.add('hidden'); }
}

document.addEventListener('DOMContentLoaded', () => {
  window.app = new XuanMuFinanceApp();
});
